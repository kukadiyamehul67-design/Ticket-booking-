import { useState } from 'react';
import { Film, Search, MapPin, Menu, User, Sparkles, Play, ChevronRight } from 'lucide-react';
import { MovieCard } from './components/MovieCard';
import { MovieDetails } from './components/MovieDetails';
import { SeatSelection } from './components/SeatSelection';
import { BookingSummary } from './components/BookingSummary';

interface Movie {
  id: string;
  title: string;
  image: string;
  genre: string;
  duration: string;
  rating: number;
  language: string;
  description: string;
  cast: string;
  director: string;
}

type View = 'intro' | 'home' | 'details' | 'seats' | 'summary';

interface BookingData {
  movie: string;
  theater: string;
  date: string;
  time: string;
  seats: string[];
  totalPrice: number;
}

export default function App() {
  const [currentView, setCurrentView] = useState<View>('intro');
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [bookingData, setBookingData] = useState<BookingData | null>(null);

  const movies: Movie[] = [
    {
      id: '1',
      title: 'Toxic',
      image: 'https://images.unsplash.com/photo-1765510296004-614b6cc204da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0aHJpbGxlciUyMG1vdmllJTIwcG9zdGVyfGVufDF8fHx8MTc2ODEyMzY0M3ww&ixlib=rb-4.1.0&q=80&w=1080',
      genre: 'Action Thriller',
      duration: '2h 45m',
      rating: 8.9,
      language: 'Hindi, Kannada',
      description: 'A gripping action thriller that follows a man\'s journey through the dangerous underworld. With intense action sequences and a compelling narrative, Toxic promises to keep audiences on the edge of their seats.',
      cast: 'Yash, Sanjay Dutt, Kiara Advani',
      director: 'Geetu Mohandas',
    },
    {
      id: '2',
      title: 'KGF Chapter 3',
      image: 'https://images.unsplash.com/photo-1645808651017-c5e3018553c7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhY3Rpb24lMjBtb3ZpZSUyMGNpbmVtYXxlbnwxfHx8fDE3NjgxOTIyMTR8MA&ixlib=rb-4.1.0&q=80&w=1080',
      genre: 'Action Drama',
      duration: '3h 10m',
      rating: 9.2,
      language: 'Kannada, Hindi, Tamil',
      description: 'The epic saga continues as Rocky rises to unprecedented heights of power. The third chapter promises even more spectacular action, drama, and an unforgettable cinematic experience.',
      cast: 'Yash, Srinidhi Shetty, Prakash Raj',
      director: 'Prashanth Neel',
    },
    {
      id: '3',
      title: 'Ramayan',
      image: 'https://images.unsplash.com/photo-1765798295423-08fbf84c53d2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlcGljJTIwbXl0aG9sb2d5JTIwcmFtYXlhbmF8ZW58MXx8fHwxNzY4MjAwODEzfDA&ixlib=rb-4.1.0&q=80&w=1080',
      genre: 'Epic Mythology',
      duration: '3h 30m',
      rating: 9.5,
      language: 'Hindi, Telugu, Tamil',
      description: 'A grand cinematic retelling of the ancient Indian epic. Experience the timeless tale of Lord Rama with stunning visuals, magnificent sets, and powerful performances that bring this legendary story to life.',
      cast: 'Ranbir Kapoor, Sai Pallavi, Yash',
      director: 'Nitesh Tiwari',
    },
    {
      id: '4',
      title: 'The Empire Strikes',
      image: 'https://images.unsplash.com/photo-1767465262698-696af3387163?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhY3Rpb24lMjBoZXJvJTIwZmlsbXxlbnwxfHx8fDE3NjgyMDA4MTR8MA&ixlib=rb-4.1.0&q=80&w=1080',
      genre: 'Action Adventure',
      duration: '2h 30m',
      rating: 8.5,
      language: 'Hindi, English',
      description: 'An action-packed adventure that takes viewers on a thrilling ride through exotic locations and heart-stopping sequences. A must-watch for action enthusiasts.',
      cast: 'Hrithik Roshan, Deepika Padukone',
      director: 'Siddharth Anand',
    },
    {
      id: '5',
      title: 'Silent Horizon',
      image: 'https://images.unsplash.com/photo-1761948245703-cbf27a3e7502?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZHZlbnR1cmUlMjBtb3ZpZSUyMGNpbmVtYXxlbnwxfHx8fDE3NjgyMDA4MTR8MA&ixlib=rb-4.1.0&q=80&w=1080',
      genre: 'Sci-Fi Thriller',
      duration: '2h 20m',
      rating: 8.3,
      language: 'Hindi, English',
      description: 'A mind-bending sci-fi thriller that explores the depths of human consciousness. With stunning visual effects and a gripping storyline, this film pushes the boundaries of cinema.',
      cast: 'Rajkummar Rao, Taapsee Pannu',
      director: 'Anurag Kashyap',
    },
    {
      id: '6',
      title: 'Warrior\'s Pride',
      image: 'https://images.unsplash.com/photo-1765510296004-614b6cc204da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkcmFtYSUyMGZpbG0lMjBwb3N0ZXJ8ZW58MXx8fHwxNzY4MTk0NTAxfDA&ixlib=rb-4.1.0&q=80&w=1080',
      genre: 'Historical Drama',
      duration: '2h 55m',
      rating: 8.8,
      language: 'Hindi, Tamil',
      description: 'A powerful historical drama that tells the inspiring story of courage and valor. Based on true events, this film celebrates the indomitable spirit of warriors.',
      cast: 'Ranveer Singh, Ajay Devgn',
      director: 'Ashutosh Gowariker',
    },
  ];

  const handleMovieClick = (movie: Movie) => {
    setSelectedMovie(movie);
    setCurrentView('details');
  };

  const handleShowtimeSelect = (date: string, time: string, theater: string) => {
    setBookingData({ 
      movie: selectedMovie!.title,
      theater, 
      date, 
      time,
      seats: [],
      totalPrice: 0,
    });
    setCurrentView('seats');
  };

  const handleSeatConfirm = (seats: string[], totalPrice: number) => {
    setBookingData(prev => prev ? { ...prev, seats, totalPrice } : null);
    setCurrentView('summary');
  };

  const handleNewBooking = () => {
    setCurrentView('home');
    setSelectedMovie(null);
    setBookingData(null);
  };

  return (
    <div className="min-h-screen bg-black">
      {/* INTRO PAGE */}
      {currentView === 'intro' && (
        <div className="relative flex min-h-screen items-center justify-center overflow-hidden">
          {/* Background Image */}
          <div className="absolute inset-0">
            <img
              src="https://images.unsplash.com/photo-1593940256067-fb4acd831804?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaW5lbWElMjB0aGVhdGVyJTIwc2VhdHN8ZW58MXx8fHwxNzY4MTkwNjI3fDA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Cinema"
              className="h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-black/70" />
            <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-transparent to-black" />
          </div>

          {/* Content */}
          <div className="relative z-10 px-8 text-center">
            {/* Logo */}
            <div className="mb-8 flex justify-center">
              <div className="rounded-2xl bg-red-600 p-6 shadow-2xl shadow-red-600/50">
                <Film className="size-16 text-white" />
              </div>
            </div>

            {/* Title */}
            <div className="mb-6">
              <h1 className="mb-2 text-7xl text-white md:text-8xl">CineBook</h1>
              <div className="flex items-center justify-center gap-2 text-xl text-red-500">
                <Sparkles className="size-5" />
                <span>Your Ultimate Movie Booking Experience</span>
                <Sparkles className="size-5" />
              </div>
            </div>

            {/* Description */}
            <p className="mx-auto mb-12 max-w-2xl text-xl text-zinc-300">
              Book tickets for the latest blockbusters including <span className="text-red-500">Toxic</span>, <span className="text-red-500">KGF Chapter 3</span>, <span className="text-red-500">Ramayan</span> and many more. Experience cinema like never before!
            </p>

            {/* CTA Button */}
            <button
              onClick={() => setCurrentView('home')}
              className="group inline-flex items-center gap-3 rounded-full bg-gradient-to-r from-red-600 to-red-700 px-12 py-6 text-xl text-white shadow-2xl shadow-red-600/50 transition-all hover:scale-105 hover:shadow-red-600/70"
            >
              <Play className="size-6 fill-white" />
              <span>Explore Movies</span>
              <ChevronRight className="size-6 transition-transform group-hover:translate-x-1" />
            </button>

            {/* Features */}
            <div className="mt-16 grid gap-8 md:grid-cols-3">
              <div className="rounded-xl border border-zinc-800 bg-black/50 p-6 backdrop-blur-sm">
                <div className="mb-3 text-4xl">🎬</div>
                <h3 className="mb-2 text-lg text-white">Latest Movies</h3>
                <p className="text-sm text-zinc-400">Watch the newest blockbusters</p>
              </div>
              <div className="rounded-xl border border-zinc-800 bg-black/50 p-6 backdrop-blur-sm">
                <div className="mb-3 text-4xl">🎟️</div>
                <h3 className="mb-2 text-lg text-white">Easy Booking</h3>
                <p className="text-sm text-zinc-400">Book your seats in seconds</p>
              </div>
              <div className="rounded-xl border border-zinc-800 bg-black/50 p-6 backdrop-blur-sm">
                <div className="mb-3 text-4xl">🏆</div>
                <h3 className="mb-2 text-lg text-white">Best Theaters</h3>
                <p className="text-sm text-zinc-400">Premium cinema experience</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* HOME PAGE - MOVIE LISTINGS */}
      {currentView === 'home' && (
        <>
          {/* Header */}
          <header className="sticky top-0 z-50 border-b border-zinc-800 bg-black/95 backdrop-blur-sm">
            <div className="mx-auto max-w-7xl px-8 py-6">
              <div className="flex items-center justify-between">
                <div 
                  className="flex items-center gap-3 cursor-pointer"
                  onClick={() => setCurrentView('intro')}
                >
                  <div className="rounded-lg bg-red-600 p-2">
                    <Film className="size-6 text-white" />
                  </div>
                  <h1 className="text-2xl text-white">CineBook</h1>
                </div>
                
                <div className="hidden md:flex flex-1 max-w-md mx-8">
                  <div className="relative w-full">
                    <Search className="absolute left-3 top-1/2 size-5 -translate-y-1/2 text-zinc-400" />
                    <input
                      type="text"
                      placeholder="Search for movies..."
                      className="w-full rounded-lg bg-zinc-900 py-2.5 pl-11 pr-4 text-white placeholder-zinc-400 outline-none focus:ring-2 focus:ring-red-600"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <button className="flex items-center gap-2 text-zinc-400 hover:text-white">
                    <MapPin className="size-5" />
                    <span className="hidden md:inline">Mumbai</span>
                  </button>
                  <button className="rounded-lg bg-zinc-900 p-2 text-zinc-400 hover:text-white">
                    <Menu className="size-5" />
                  </button>
                  <button className="rounded-lg bg-red-600 p-2 text-white hover:bg-red-700">
                    <User className="size-5" />
                  </button>
                </div>
              </div>
            </div>
          </header>

          {/* Movies Section */}
          <main className="mx-auto max-w-7xl px-8 py-12">
            <div className="mb-8 flex items-center justify-between">
              <h2 className="text-3xl text-white">Now Showing</h2>
              <div className="flex items-center gap-2 text-sm text-zinc-400">
                <span>{movies.length} Movies</span>
              </div>
            </div>
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {movies.map(movie => (
                <MovieCard
                  key={movie.id}
                  {...movie}
                  onClick={() => handleMovieClick(movie)}
                />
              ))}
            </div>
          </main>

          {/* Footer */}
          <footer className="border-t border-zinc-800 bg-zinc-900 py-12">
            <div className="mx-auto max-w-7xl px-8">
              <div className="grid gap-8 md:grid-cols-4">
                <div>
                  <div className="mb-4 flex items-center gap-2">
                    <div className="rounded-lg bg-red-600 p-2">
                      <Film className="size-5 text-white" />
                    </div>
                    <h3 className="text-xl text-white">CineBook</h3>
                  </div>
                  <p className="text-sm text-zinc-400">
                    Your premier destination for booking movie tickets online.
                  </p>
                </div>
                <div>
                  <h4 className="mb-4 text-white">Movies</h4>
                  <ul className="space-y-2 text-sm text-zinc-400">
                    <li><a href="#" className="hover:text-white">Now Showing</a></li>
                    <li><a href="#" className="hover:text-white">Coming Soon</a></li>
                    <li><a href="#" className="hover:text-white">Top Rated</a></li>
                  </ul>
                </div>
                <div>
                  <h4 className="mb-4 text-white">Support</h4>
                  <ul className="space-y-2 text-sm text-zinc-400">
                    <li><a href="#" className="hover:text-white">Help Center</a></li>
                    <li><a href="#" className="hover:text-white">Terms of Service</a></li>
                    <li><a href="#" className="hover:text-white">Privacy Policy</a></li>
                  </ul>
                </div>
                <div>
                  <h4 className="mb-4 text-white">Contact</h4>
                  <ul className="space-y-2 text-sm text-zinc-400">
                    <li>support@cinebook.com</li>
                    <li>+91 1800-123-4567</li>
                    <li>Mumbai, India</li>
                  </ul>
                </div>
              </div>
              <div className="mt-8 border-t border-zinc-800 pt-8 text-center text-sm text-zinc-500">
                © 2026 CineBook. All rights reserved.
              </div>
            </div>
          </footer>
        </>
      )}

      {/* MOVIE DETAILS PAGE */}
      {currentView === 'details' && selectedMovie && (
        <MovieDetails
          movie={selectedMovie}
          onBack={() => setCurrentView('home')}
          onSelectShowtime={handleShowtimeSelect}
        />
      )}

      {/* SEAT SELECTION PAGE */}
      {currentView === 'seats' && bookingData && (
        <SeatSelection
          movie={bookingData.movie}
          theater={bookingData.theater}
          date={bookingData.date}
          time={bookingData.time}
          onBack={() => setCurrentView('details')}
          onConfirm={handleSeatConfirm}
        />
      )}

      {/* BOOKING SUMMARY PAGE */}
      {currentView === 'summary' && bookingData && (
        <BookingSummary
          movie={bookingData.movie}
          theater={bookingData.theater}
          date={bookingData.date}
          time={bookingData.time}
          seats={bookingData.seats}
          totalPrice={bookingData.totalPrice}
          onNewBooking={handleNewBooking}
        />
      )}
    </div>
  );
}

import { ArrowLeft, Calendar, Clock, Star } from 'lucide-react';

interface Movie {
  id: string;
  title: string;
  image: string;
  genre: string;
  duration: string;
  rating: number;
  language: string;
  description: string;
  cast: string;
  director: string;
}

interface MovieDetailsProps {
  movie: Movie;
  onBack: () => void;
  onSelectShowtime: (date: string, time: string, theater: string) => void;
}

export function MovieDetails({ movie, onBack, onSelectShowtime }: MovieDetailsProps) {
  const dates = [
    { day: 'MON', date: '13 JAN' },
    { day: 'TUE', date: '14 JAN' },
    { day: 'WED', date: '15 JAN' },
    { day: 'THU', date: '16 JAN' },
  ];

  const showtimes = [
    { theater: 'PVR Cinemas - Central Mall', times: ['10:30 AM', '1:45 PM', '5:00 PM', '8:15 PM'] },
    { theater: 'INOX - City Square', times: ['11:00 AM', '2:30 PM', '6:00 PM', '9:30 PM'] },
    { theater: 'Cinépolis - Downtown', times: ['12:00 PM', '3:15 PM', '6:45 PM', '10:00 PM'] },
  ];

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <div className="relative h-[60vh] overflow-hidden">
        <img 
          src={movie.image} 
          alt={movie.title}
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent" />
        
        <button
          onClick={onBack}
          className="absolute left-4 top-4 flex items-center gap-2 rounded-lg bg-black/50 px-4 py-2 backdrop-blur-sm transition-colors hover:bg-black/70"
        >
          <ArrowLeft className="size-5" />
          <span>Back</span>
        </button>

        <div className="absolute bottom-0 left-0 right-0 p-8">
          <h1 className="mb-4 text-5xl">{movie.title}</h1>
          <div className="flex flex-wrap items-center gap-4 text-zinc-300">
            <div className="flex items-center gap-2">
              <Star className="size-5 fill-yellow-400 text-yellow-400" />
              <span className="text-xl">{movie.rating}/10</span>
            </div>
            <span>•</span>
            <span>{movie.genre}</span>
            <span>•</span>
            <div className="flex items-center gap-2">
              <Clock className="size-4" />
              <span>{movie.duration}</span>
            </div>
            <span>•</span>
            <span>{movie.language}</span>
          </div>
        </div>
      </div>

      {/* Details Section */}
      <div className="mx-auto max-w-7xl px-8 py-12">
        <div className="mb-12 grid gap-8 md:grid-cols-2">
          <div>
            <h2 className="mb-4 text-2xl">About the Movie</h2>
            <p className="mb-6 leading-relaxed text-zinc-400">{movie.description}</p>
            <div className="space-y-3 text-zinc-400">
              <p><span className="text-white">Director:</span> {movie.director}</p>
              <p><span className="text-white">Cast:</span> {movie.cast}</p>
            </div>
          </div>
        </div>

        {/* Showtimes */}
        <div>
          <h2 className="mb-6 text-3xl">Select Showtime</h2>
          
          {/* Date Selection */}
          <div className="mb-8 flex gap-4 overflow-x-auto pb-2">
            {dates.map((date, index) => (
              <button
                key={index}
                className="flex min-w-[120px] flex-col items-center rounded-lg border border-zinc-800 bg-zinc-900 px-6 py-4 transition-colors hover:border-red-600 hover:bg-red-600/10"
              >
                <span className="text-sm text-zinc-400">{date.day}</span>
                <span className="mt-1 text-lg">{date.date}</span>
              </button>
            ))}
          </div>

          {/* Theater Showtimes */}
          <div className="space-y-6">
            {showtimes.map((showtime, index) => (
              <div key={index} className="rounded-lg border border-zinc-800 bg-zinc-900 p-6">
                <div className="mb-4 flex items-center gap-2">
                  <Calendar className="size-5 text-red-500" />
                  <h3 className="text-xl">{showtime.theater}</h3>
                </div>
                <div className="flex flex-wrap gap-3">
                  {showtime.times.map((time, timeIndex) => (
                    <button
                      key={timeIndex}
                      onClick={() => onSelectShowtime(dates[0].date, time, showtime.theater)}
                      className="rounded-lg border border-zinc-700 bg-zinc-800 px-6 py-3 transition-colors hover:border-green-500 hover:bg-green-500/10"
                    >
                      {time}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

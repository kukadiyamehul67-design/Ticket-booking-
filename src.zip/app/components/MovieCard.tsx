import { Star, Clock } from 'lucide-react';

interface MovieCardProps {
  id: string;
  title: string;
  image: string;
  genre: string;
  duration: string;
  rating: number;
  language: string;
  onClick: () => void;
}

export function MovieCard({ title, image, genre, duration, rating, language, onClick }: MovieCardProps) {
  return (
    <div 
      className="group cursor-pointer overflow-hidden rounded-lg bg-zinc-900 transition-transform hover:scale-105"
      onClick={onClick}
    >
      <div className="relative aspect-[2/3] overflow-hidden">
        <img 
          src={image} 
          alt={title}
          className="h-full w-full object-cover transition-transform group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <div className="flex items-center gap-2 text-sm text-yellow-400">
            <Star className="size-4 fill-yellow-400" />
            <span>{rating}/10</span>
          </div>
        </div>
      </div>
      <div className="p-4">
        <h3 className="mb-2 text-lg text-white">{title}</h3>
        <div className="flex flex-wrap items-center gap-2 text-sm text-zinc-400">
          <span>{genre}</span>
          <span>•</span>
          <div className="flex items-center gap-1">
            <Clock className="size-3" />
            <span>{duration}</span>
          </div>
          <span>•</span>
          <span>{language}</span>
        </div>
      </div>
    </div>
  );
}

import { CheckCircle2, Ticket, MapPin, Calendar, Clock, Armchair } from 'lucide-react';

interface BookingSummaryProps {
  movie: string;
  theater: string;
  date: string;
  time: string;
  seats: string[];
  totalPrice: number;
  onNewBooking: () => void;
}

export function BookingSummary({ 
  movie, 
  theater, 
  date, 
  time, 
  seats, 
  totalPrice, 
  onNewBooking 
}: BookingSummaryProps) {
  const bookingId = 'BK' + Math.random().toString(36).substring(2, 11).toUpperCase();

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="mx-auto max-w-2xl px-8 py-16">
        {/* Success Icon */}
        <div className="mb-8 flex justify-center">
          <div className="rounded-full bg-green-500/20 p-6">
            <CheckCircle2 className="size-16 text-green-500" />
          </div>
        </div>

        {/* Success Message */}
        <div className="mb-12 text-center">
          <h1 className="mb-2 text-4xl">Booking Confirmed!</h1>
          <p className="text-zinc-400">Your tickets have been booked successfully</p>
        </div>

        {/* Booking Details Card */}
        <div className="mb-8 overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900">
          {/* Ticket Header */}
          <div className="border-b border-zinc-800 bg-gradient-to-r from-red-600 to-red-700 p-6">
            <div className="mb-2 flex items-center justify-between">
              <Ticket className="size-6" />
              <span className="text-sm opacity-90">Booking ID: {bookingId}</span>
            </div>
            <h2 className="text-2xl">{movie}</h2>
          </div>

          {/* Ticket Body */}
          <div className="p-6">
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <MapPin className="size-5 text-zinc-400 mt-0.5" />
                <div>
                  <p className="text-sm text-zinc-400">Theater</p>
                  <p className="text-lg">{theater}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-start gap-3">
                  <Calendar className="size-5 text-zinc-400 mt-0.5" />
                  <div>
                    <p className="text-sm text-zinc-400">Date</p>
                    <p className="text-lg">{date}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Clock className="size-5 text-zinc-400 mt-0.5" />
                  <div>
                    <p className="text-sm text-zinc-400">Time</p>
                    <p className="text-lg">{time}</p>
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Armchair className="size-5 text-zinc-400 mt-0.5" />
                <div>
                  <p className="text-sm text-zinc-400">Seats ({seats.length})</p>
                  <p className="text-lg">{seats.sort().join(', ')}</p>
                </div>
              </div>
            </div>

            {/* Price Breakdown */}
            <div className="mt-6 border-t border-zinc-800 pt-6">
              <div className="mb-2 flex justify-between text-zinc-400">
                <span>Ticket Price ({seats.length} × ₹250)</span>
                <span>₹{totalPrice}</span>
              </div>
              <div className="mb-2 flex justify-between text-zinc-400">
                <span>Convenience Fee</span>
                <span>₹50</span>
              </div>
              <div className="flex justify-between text-xl">
                <span>Total Amount</span>
                <span className="text-green-500">₹{totalPrice + 50}</span>
              </div>
            </div>
          </div>

          {/* Perforated Edge Effect */}
          <div className="flex justify-between border-t border-zinc-800 px-2">
            {Array.from({ length: 20 }, (_, i) => (
              <div key={i} className="h-3 w-3 rounded-full bg-black translate-y-[-6px]" />
            ))}
          </div>

          {/* QR Code Section */}
          <div className="bg-zinc-800 p-6">
            <div className="mx-auto flex h-32 w-32 items-center justify-center rounded-lg bg-white">
              <div className="grid grid-cols-8 gap-0.5">
                {Array.from({ length: 64 }, (_, i) => (
                  <div 
                    key={i} 
                    className={`h-1 w-1 ${Math.random() > 0.5 ? 'bg-black' : 'bg-white'}`}
                  />
                ))}
              </div>
            </div>
            <p className="mt-4 text-center text-sm text-zinc-400">
              Show this QR code at the theater entrance
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-4">
          <button
            onClick={onNewBooking}
            className="flex-1 rounded-lg border border-zinc-700 bg-zinc-800 py-4 transition-colors hover:bg-zinc-700"
          >
            Book Another Movie
          </button>
          <button className="flex-1 rounded-lg bg-red-600 py-4 transition-colors hover:bg-red-700">
            Download Ticket
          </button>
        </div>
      </div>
    </div>
  );
}

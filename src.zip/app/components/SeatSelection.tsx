import { ArrowLeft, Users } from 'lucide-react';
import { useState } from 'react';

interface SeatSelectionProps {
  movie: string;
  theater: string;
  date: string;
  time: string;
  onBack: () => void;
  onConfirm: (seats: string[], totalPrice: number) => void;
}

export function SeatSelection({ movie, theater, date, time, onBack, onConfirm }: SeatSelectionProps) {
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);

  const rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];
  const seatsPerRow = 12;
  const pricePerSeat = 250;

  // Mock some occupied seats
  const occupiedSeats = ['A5', 'A6', 'B7', 'C3', 'C4', 'D8', 'E5', 'E6', 'F9', 'G4', 'G5', 'H7'];

  const toggleSeat = (seatId: string) => {
    if (occupiedSeats.includes(seatId)) return;
    
    setSelectedSeats(prev => 
      prev.includes(seatId) 
        ? prev.filter(s => s !== seatId)
        : [...prev, seatId]
    );
  };

  const getSeatStatus = (seatId: string) => {
    if (occupiedSeats.includes(seatId)) return 'occupied';
    if (selectedSeats.includes(seatId)) return 'selected';
    return 'available';
  };

  const getSeatClass = (status: string) => {
    switch (status) {
      case 'occupied':
        return 'bg-zinc-700 cursor-not-allowed';
      case 'selected':
        return 'bg-green-500 hover:bg-green-600';
      case 'available':
        return 'bg-zinc-800 hover:bg-zinc-700 border border-zinc-600';
      default:
        return '';
    }
  };

  const totalPrice = selectedSeats.length * pricePerSeat;

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="border-b border-zinc-800 bg-zinc-900 px-8 py-6">
        <button
          onClick={onBack}
          className="mb-4 flex items-center gap-2 text-zinc-400 transition-colors hover:text-white"
        >
          <ArrowLeft className="size-5" />
          <span>Back</span>
        </button>
        <h1 className="mb-2 text-3xl">{movie}</h1>
        <div className="flex flex-wrap gap-4 text-sm text-zinc-400">
          <span>{theater}</span>
          <span>•</span>
          <span>{date}</span>
          <span>•</span>
          <span>{time}</span>
        </div>
      </div>

      <div className="mx-auto max-w-5xl px-8 py-12">
        {/* Screen */}
        <div className="mb-16">
          <div className="mx-auto h-2 w-3/4 rounded-full bg-gradient-to-r from-transparent via-zinc-600 to-transparent" />
          <p className="mt-3 text-center text-sm text-zinc-500">SCREEN</p>
        </div>

        {/* Seating Chart */}
        <div className="mb-12">
          {rows.map(row => (
            <div key={row} className="mb-3 flex items-center justify-center gap-2">
              <span className="w-8 text-center text-sm text-zinc-500">{row}</span>
              {Array.from({ length: seatsPerRow }, (_, i) => {
                const seatNumber = i + 1;
                const seatId = `${row}${seatNumber}`;
                const status = getSeatStatus(seatId);
                
                return (
                  <button
                    key={seatId}
                    onClick={() => toggleSeat(seatId)}
                    disabled={status === 'occupied'}
                    className={`size-8 rounded-md text-xs transition-all ${getSeatClass(status)}`}
                    title={seatId}
                  >
                    {seatNumber}
                  </button>
                );
              })}
              <span className="w-8 text-center text-sm text-zinc-500">{row}</span>
            </div>
          ))}
        </div>

        {/* Legend */}
        <div className="mb-12 flex justify-center gap-8 text-sm">
          <div className="flex items-center gap-2">
            <div className="size-6 rounded-md bg-zinc-800 border border-zinc-600" />
            <span className="text-zinc-400">Available</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="size-6 rounded-md bg-green-500" />
            <span className="text-zinc-400">Selected</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="size-6 rounded-md bg-zinc-700" />
            <span className="text-zinc-400">Occupied</span>
          </div>
        </div>

        {/* Booking Summary */}
        {selectedSeats.length > 0 && (
          <div className="fixed bottom-0 left-0 right-0 border-t border-zinc-800 bg-zinc-900 px-8 py-6">
            <div className="mx-auto flex max-w-5xl items-center justify-between">
              <div>
                <div className="mb-1 flex items-center gap-2 text-zinc-400">
                  <Users className="size-4" />
                  <span className="text-sm">{selectedSeats.length} Seat{selectedSeats.length > 1 ? 's' : ''}</span>
                </div>
                <p className="text-sm text-zinc-500">
                  {selectedSeats.sort().join(', ')}
                </p>
              </div>
              <div className="flex items-center gap-6">
                <div className="text-right">
                  <p className="text-sm text-zinc-400">Total Amount</p>
                  <p className="text-2xl">₹{totalPrice}</p>
                </div>
                <button
                  onClick={() => onConfirm(selectedSeats, totalPrice)}
                  className="rounded-lg bg-red-600 px-8 py-3 transition-colors hover:bg-red-700"
                >
                  Proceed to Pay
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
